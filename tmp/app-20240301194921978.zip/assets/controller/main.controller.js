(function () {
  'use strict';

  angularjs.controller('angularjs', ['$scope', 'zendeskService', function ($scope, zendeskService) {

    //Inicia PROCURAR USUÁRIO!!!

    document.getElementById('searchUserForm').addEventListener('submit', function (event) {
      event.preventDefault()

      var userName = document.getElementById('userName').value;

      zendeskService.searchUser(userName).then(function (user) {
        $scope.user = user;
        document.getElementById('showUser').hidden = false;
        
        user.users.forEach(element => {
          var listNome = document.createElement('li');
          listNome.textContent = 'Nome: '+element.name;
          var listEmail = document.createElement('li');
          listEmail.textContent = 'E-mail:'+element.email;
          usersList.appendChild(listNome);
          usersList.appendChild(listEmail);
        });
      });

    });

    //Finaliza PROCURAR USUÁRIO!!!

    //Inicia CONTAR USUÁRIOS!!!

    document.getElementById('countUserForm').addEventListener('submit', function (event) {
      event.preventDefault()

      zendeskService.countUsers().then(function (count) {
        $scope.count = count.count;
        document.getElementById('showCount').hidden = false;
        //console.log(count);
      });

    });

    //Finaliza CONTAR USUÁRIOS!!!

  }]);

})();